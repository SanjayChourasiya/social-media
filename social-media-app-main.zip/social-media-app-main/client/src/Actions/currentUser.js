export const setCurrentUser = (data) => {

    return{
        type: 'CURRENT_USER',
        payload: data
    }
}
